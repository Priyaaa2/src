package com.mphasis.jms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
