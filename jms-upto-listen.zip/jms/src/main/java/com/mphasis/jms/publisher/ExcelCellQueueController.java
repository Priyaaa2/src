package com.mphasis.jms.publisher;

import com.mphasis.jms.model.ExcelCellMessage;
import com.mphasis.jms.service.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class ExcelCellQueueController {

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    ExcelService excelService;

    @PostMapping("/pushmessage")
    public ResponseEntity<String> pushMessageToJms(@RequestBody ExcelCellMessage excelCellMessage) {
        try {
            jmsTemplate.convertAndSend("excel-error-queue", excelCellMessage);
            return new ResponseEntity<>("Message sent", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
        	System.out.println("Sending file...");
            excelService.upload(file);
            return new ResponseEntity<>("file uploaded", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
