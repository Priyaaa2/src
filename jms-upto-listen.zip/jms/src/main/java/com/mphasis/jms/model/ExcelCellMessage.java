package com.mphasis.jms.model;

import java.io.Serializable;

public class ExcelCellMessage implements Serializable {

	private static final long serialVersionUID = 7077738031554276706L;
	private static String role;
	private static String department;
	private static String LastName;

	private String EmployeeID;

	private String FirstName;

	private String error;

	private String status;

	public static String getRole() {
		return role;
	}

	public static void setRole(String role) {
		ExcelCellMessage.role = role;
	}

	public static String getDepartment() {
		return department;
	}

	public static void setDepartment(String department) {
		ExcelCellMessage.department = department;
	}

	public static String getLastName() {
		return LastName;
	}

	public static void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmployeeID() {
		return EmployeeID;
	}

	public void setEmployeeID(String employeeID) {
		EmployeeID = employeeID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ExcelCellMessage [EmployeeID=" + EmployeeID + ", FirstName=" + FirstName + ", error=" + error
				+ ", status=" + status + "]";
	}
}
