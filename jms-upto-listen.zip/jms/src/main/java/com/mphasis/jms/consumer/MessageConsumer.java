package com.mphasis.jms.consumer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.asm.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mphasis.jms.model.ExcelCellMessage;

@Service
public class MessageConsumer {
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	JmsTemplate jmsTemplate;
	
	@Autowired
	Queue queue;

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageConsumer.class);

//    @JmsListener(destination = "inMemory.queue")
//    public void excelErrorListener(String excelCellMessage){
//        LOGGER.info("message " +
//                "received {}", excelCellMessage);
//        Object data = null;
//		try {
//			data = objectMapper.readValue(excelCellMessage, new com.fasterxml.jackson.core.type.TypeReference<Object>() {
//			});
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//        System.out.println(data);
//    }
    
    @JmsListener(destination = "inMemory.queue")
    public void excelErrorListener(List<ExcelCellMessage> excelCellMessage){
    	System.out.println("Listening..");
        LOGGER.info("message " +
                "received {}", excelCellMessage);
        

    }
}
