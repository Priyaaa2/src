package com.mphasis.jms.service;

import com.mphasis.jms.model.ExcelCellMessage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.Queue;
import javax.jms.Topic;

@Service
public class ExcelService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelService.class);
    @Autowired
    JmsTemplate jmsTemplate;
    @Autowired
    private Queue queue;
    public void upload(MultipartFile file) {
        try {
            List<ExcelCellMessage> ExcelCellMessage = readExcelAndPushErrors(file.getInputStream());
            
//            for (ExcelCellMessage data : ExcelCellMessage) {
//                if (data == null || data.getEmployee()==null || data.getDescription() == null) {
                    pushToJms(ExcelCellMessage);
//                }
//            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void pushToJms(List<ExcelCellMessage> excelCellMessage) {
        LOGGER.info("Pushing data {}", excelCellMessage);
//        jmsTemplate.setPubSubDomain(true);
        jmsTemplate.convertAndSend(queue, excelCellMessage);
        
        //jmsTemplate.convertAndSend(topic, data.toString());
    }
 
    public static List<ExcelCellMessage> readExcelAndPushErrors(InputStream is) {
        try {
            Workbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheet("Sheet1");
            Iterator<Row> rows = sheet.iterator();
            List<ExcelCellMessage> ExcelCellMessageList = new ArrayList<>();
            int rowNumber = 0;
            while (rows.hasNext()) {
                Row currentRow = rows.next();
                // skip header
                if (rowNumber == 0) {
                    rowNumber++;
                    continue;
                }
                Iterator<Cell> cellsInRow = currentRow.iterator();
                ExcelCellMessage ExcelCellMessage = new ExcelCellMessage();
                int cellIdx = 0;
                while (cellsInRow.hasNext()) {
                    Cell currentCell = cellsInRow.next();
                    switch (cellIdx) {
                        case 0:
                        	Double empId = currentCell.getNumericCellValue();
                            ExcelCellMessage.setEmployeeID(empId.toString());
                            break;
                        case 1:
                            ExcelCellMessage.setFirstName(currentCell.getStringCellValue());
                            break;
                        case 2:
                        	ExcelCellMessage.setLastName(currentCell.getStringCellValue());
                            break;
                        case 3:
                        	ExcelCellMessage.setRole(currentCell.getStringCellValue());
                            break;
                        case 4:
                        	Double dept = currentCell.getNumericCellValue();
                        	ExcelCellMessage.setDepartment(dept.toString());
                            break;
                        case 5:
                        	ExcelCellMessage.setStatus(currentCell.getStringCellValue());
                            break;
                        case 6:
                        	ExcelCellMessage.setError(currentCell.getStringCellValue());
                            break;
                        	
                        default:
                            break;
                    }
                    cellIdx++;
                }
                ExcelCellMessageList.add(ExcelCellMessage);
            }
            workbook.close();
            return ExcelCellMessageList;
        } catch (IOException e) {
        	e.printStackTrace();
            throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
        }
    }
}
