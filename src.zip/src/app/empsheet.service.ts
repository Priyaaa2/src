import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class EmpsheetService {
  URL:string = "";
  http: any;
  constructor(private apiCall:HttpClient) { }

  postSheet(data) {
    const formData = new FormData();
    const header:any = {"content-type": "multipart/form-data"};
    formData.append('file', data.item(0));
    return this.apiCall.post<any>('http://localhost:9070/upload', formData, header);
  }


//  getTableData() {
  
//   let headers = new HttpHeaders()

//   // headers = headers.set('content-type', 'Basic blah');
//   headers = headers.set("Access-Control-Allow-Origin", "*");
//   // const header:any ={"content-type":"application.json"};
//  return this.apiCall.get('http://localhost:9070/validatedResponsePath',{ headers });
//  }

 public getTableData(): Observable<any> {
  let headers = new HttpHeaders()
     headers.set('content-type', 'application/json');
     headers.set("Access-Control-Allow-Origin", "*");    
  return this.apiCall.get('http://localhost:9070/validatedResponseFilePath',{headers}).pipe(map(res => res)
  );
}

}

