import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExcelsheetComponent } from './excelsheet/excelsheet.component';
import { ReplaceNullWithTextPipe } from './replace-null-with-text.pipe';
import { EmpsheetService } from 'src/app/empsheet.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ExcelsheetComponent,
    ReplaceNullWithTextPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [ReplaceNullWithTextPipe, EmpsheetService],
  bootstrap: [AppComponent]
})
export class AppModule { }
