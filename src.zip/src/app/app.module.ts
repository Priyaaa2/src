import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExcelsheetComponent } from './excelsheet/excelsheet.component';
import { ReplaceNullWithTextPipe } from './replace-null-with-text.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ExcelsheetComponent,
    ReplaceNullWithTextPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [ReplaceNullWithTextPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
