import { TestBed } from '@angular/core/testing';

import { EmpsheetService } from './empsheet.service';

describe('EmpsheetService', () => {
  let service: EmpsheetService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmpsheetService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
