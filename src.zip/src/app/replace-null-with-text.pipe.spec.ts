import { ReplaceNullWithTextPipe } from './replace-null-with-text.pipe';

describe('ReplaceNullWithTextPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceNullWithTextPipe();
    expect(pipe).toBeTruthy();
  });
});
