import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'replaceNullWithText'
})
export class ReplaceNullWithTextPipe implements PipeTransform {

  transform(value: unknown, args: unknown,args1:unknown): unknown {
    debugger
    return null;
  }

}
